function dn = tiff_datenum(fname)
fid = fopen(fname);
tline = fgetl(fid);
while ischar(tline)
    if contains(tline,'acquisition-time-local')
        info = strsplit(tline,'=');
        dstr = erase(info(end),{'"';'/>'});
        dn = datenum(dstr,'yyyymmdd HH:MM:SS.FFF');
        fclose(fid);
        return
    end
    
    tline = fgetl(fid);
end
dn = NaN;
fclose(fid);

end