function timepoints = track3_KA_children(dirname,paramfile)
% TIMEPOINTS = MUNKRES(IN, OUT)  returns a
% timepoints objects structure with tracking numbers corresponding to
% individual lineages.
% CXY   - maximum travel distance
% CAREA - maximal fold change in area
% CGR   - maximal fold change in red or green fluorescence level - NOT USED
% MAXSKIP - maximal number of ommitted frames
% created, HYK 6/24/11
% edited HYK 8/26/2018 - to include cell division tracking

set(0,'RecursionLimit',50000);

% tracking parameters;
p = load(paramfile);
in = [dirname '/' p.segfile];    % the filename for the segmentation data only
out = [dirname '/' p.segtrackfile];  % the filename for the tracking data
Cxy = p.Cxy;
Carea = p.Carea;
%Cf = p.Cf;   %0.5;     % maximal fold change in fluorescence level
maxskip = p.maxskip;   %1; % the total possible number of ommitted frames

% cell division tracking parameters
dr_dist = p.dr_dist; 
dr_avgdist = p.dr_avgdist;
f_sizesum = p.f_sizesum;

load(in);      % this is the MATLAB data file containing the segmented objects

sch = Schnitz3(objects);    % create the schnitz structure
T = sch.T;                  % the total number of timepoints
%Ls = [];   % lengths of all the tracks;  don't seem to need this, just use
%the Schnitz structure as much as possible

%% loop through all pairs of tracks
for i = 1:(T-1)
    i;
    
    if (i == 1)   % first time point, initialize the objnow structure
        if length(sch.obj(i)) > 0  % this is the total number of objects in the first frame
            for m = 1:length(sch.obj(i))
                objnow(m).t = i;        % this is the timepoint number, useful later for omitted tracks
                objnow(m).ind = m;      % this is the index number
                objnow(m).skipped = 0;
                sch.addtotrack(0,1,m);       % seed new track numbers
            end
        else
            objnow = [];
        end
    else  % subsequent time points, alter objnow structure to carry over old objects and add new ones
        if exist('objcarry');
            objnow = objcarry;      % these are the untracked objects from prior frames
        else
            objnow = [];
        end    
        for m = 1:length(sch.obj(i));  % loop through object structure, append new objects 
            objnow(end+1).t = i;   % append new object to the end
            objnow(end).ind = m;
            objnow(end).skipped = 0;
            if ~(sch.tr(i,m))   % if object has not already been assigned to track
                sch.addtotrack(0,i,m);       % seed a new track number
            end
        end
    end
    % compute cost matrix
    M = length(objnow);  % number of objects in first time frame
    N = length(sch.obj(i+1));    % number of objects in subsequent time frame
    
    if (M==0)
        continue
    end
    
    % KA added below chunk for specific case when there are objects in
    % current frame but not in subsequent (N==0)
    if (N==0)
        % find way to add current objects to objcarry    
        c = 1;   % the index of the objects to be carried over
        clear objcarry;
        for m = 1:M
            objnow(m).skipped = objnow(m).skipped + 1;   % increment the skipped frame number for this particular object
            if (objnow(m).skipped <= maxskip)     % carry this object over to the last frame
                objcarry(c) = objnow(m);
                c = c+1;
            end
        end
        continue
    end
    
    % these are all the variables that go into the cost function
    xs1 = zeros(M,N);
    ys1 = zeros(M,N);
    areas1 = zeros(M,N);
    gates1 = zeros(M,N);
    
    xs2 = zeros(M,N);
    ys2 = zeros(M,N);
    areas2 = zeros(M,N);
    gates2 = zeros(M,N);
    
    for m = 1:M      % compute inputs into cost matrix for initial frame
        t1 = objnow(m).t;   % this is the timepoint and the index information for the current timepoint
        ind1 = objnow(m).ind;
        xs1(m,:) = sch.objdata(t1,ind1).x; 
        ys1(m,:) = sch.objdata(t1,ind1).y;
        areas1(m,:) = sch.objdata(t1,ind1).area;
        %gate = objects(t1).obj(ind1).gate;
        %gates1(m,:) = gate;
    end

    t2 = i+1;
    for n = 1:N        % cost inputs into cost matrix for subsequent frame
        ind2 = n;
        xs2(:,n) = sch.objdata(t2,ind2).x;
        ys2(:,n) = sch.objdata(t2,ind2).y;
        areas2(:,n) = sch.objdata(t2,ind2).area;
        %gate = objects(t2).obj(ind2).gate;
        %gates2(:,n) = gate;
    end
    
    % construct cost function
    Dxy = sqrt((xs2-xs1).^2 + (ys2-ys1).^2)./Cxy;
    Dxy(find(Dxy > 1)) = Inf;
    
    Dareas = abs(log2(areas2./areas1));   % modified 072715 - changed expression to measure fold change in area
    Dareas(find(Dareas > Carea)) = Inf;
    
    Dgates = abs(gates2-gates1);
    Dgates(find(Dgates > 0)) = Inf;   % forbidden assignment for anything that does not fall into the same gate
    
    cost = Dxy + Dareas + Dgates;
    
    % perform assignment using cost matrix
    assign = assignmentoptimal(cost);    % thanks to markus buehren
    
    
%     %% now, check each of the initial objects for possibility for possible
%     % cell division
    D = Dxy*Cxy;  % this is the absolute distance

    clear divided;
    divided(M).d1 = [];
    divided(M).d2 = [];
    for m = 1:M   % loop over all objects
        drs = find(D(m,:)< dr_dist);  % here are the number of daughters
        if (length(drs)==2)  % if there are two cells in parental proximity, perform test  
            %disp('found 2 daughters at timepoint:')
            %i
            p_x = xs1(m,1);   % x centroid of parent
            p_y = ys1(m,1);    % y centroid of parent
            dr_x = mean([xs2(1,drs(1)) xs2(1,drs(2))]);    % average x centroid of two daughters
            dr_y = mean([ys2(1,drs(1)) ys2(1,drs(2))]);    % average y centroid of two daughters 
            davg = sqrt((p_x-dr_x)^2 + (p_y-dr_y)^2);  % distance from the parent to the average of the two daughters
%             disp('davg:')
%             davg
            if (davg < dr_avgdist);   % average centroid of two daughter cells are sufficiently close that of parent
                %disp('passed centroid test')
                a1 = areas1(m,1);
                a2 = areas2(1,drs(1))+areas2(1,drs(2));
                if (abs(log2(a2/a1))<f_sizesum)   % fold difference in areas between parent and sum areas of two daughters is less than a critical value 
                    %disp('passed fold size test')
                    % classify this event as a cell division event
                    divided(m).d1 = drs(1);  
                    divided(m).d2 = drs(2);
                    % remove the assignments to itself or other 
                    assign(find(assign == drs(1))) = 0;   % remove the other assignments 
                    assign(find(assign == drs(2))) = 0;    
                end
            end
        end
    end
       
    c = 1;   % the index of the objects to be carried over
    clear objcarry;    % clear up carry over matrix
        
    % now assignment the specific objects to the tracks
    for m = 1:M       % loop through all the parental objects to be tracked
        if (assign(m))   % an assignment was made but no cell division was detected          
            if isempty(divided(m).d1)% 
                t1 = objnow(m).t;
                t2 = (i+1);
                ind1 = objnow(m).ind;
                ind2 = assign(m);
                sch.addtotrack(sch.tr(t1,ind1), t2, ind2);   % assign object to new track
            end
        elseif (~isempty(divided(m).d1))    % cell division was detected
%             disp('m:')
%             m
            t1 = objnow(m).t;
            t2 = (i+1);   % this is the next time point;
            ind1 = objnow(m).ind;
            sch.addtotrack(0,t2,divided(m).d1);  % create new track for first daughter
            sch.addchild(sch.tr(t1,ind1),sch.Tr);           % link first daughter to parent
            sch.addtotrack(0,t2,divided(m).d2);  % create new track for second daughter
            sch.addchild(sch.tr(t1,ind1),sch.Tr);           % link second daughter to parent
            fprintf(['parent:' num2str(sch.tr(t1,ind1)) ', child:' num2str(sch.Tr-1) ',' num2str(sch.Tr) ', timepoint:' num2str(i) '\n']);
            
        else     % an assignment was NOT made, check to see if object needs to be carried over
            objnow(m).skipped = objnow(m).skipped + 1;   % increment the skipped frame number for this particular object
            if (objnow(m).skipped <= maxskip)     % carry this object over to the last frame
                objcarry(c) = objnow(m);
                c = c+1;
            end
        end
    end
    % alter the assignment to include the possibility of cell division
end

objects = sch.timepoints;
tracks = sch.tracks;

save(out, 'objects', 'tracks', 'gatenames');
end