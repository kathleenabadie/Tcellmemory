function [seg] = cellseg_simple(im,paramfile,varargin)

%% load and unpack parameters
p = load(paramfile);
nstd = p.nstd;   % number of standard deviations above background intensities for contrast


%% define image analysis filters


%% start processing routine
im = double(im);  % convert to double
original = im; %save unprocessed image for regionprops calcs

%make list of processing functions for use in for loop
funcs = {@(im) contrast_adjust(im,nstd), 'Contrast Adjust'; %see function defined below
         @(im) im > 0.05, 'Intensity Threshold';
         };
     
N_steps = size(funcs,1);

show_process = false;     
if ~isempty(varargin)
    show_process = varargin{1};
end

if show_process
    figure()
    sub_cols = ceil(sqrt(N_steps+1));
    sub_rows = ceil((N_steps+1)/sub_cols);
    subplot(sub_rows,sub_cols,1)
    imshow(im,[min(im(:)),max(im(:))])
    title('Original Image')
end

for i = 1:size(funcs,1)
    fun = funcs{i,1};
    im = fun(im);
    if show_process
        subplot(sub_rows,sub_cols,i+1)
        imshow(im,[double(min(im(:))),double(max(im(:)))])
        title(funcs{i,2})
    end
end
seg = im; %this is now the fully segmented image
end