clear sch
sch = Schnitz(tracks);


sch.trackobj(480)
sch.trackobj(481)

%sch.jointrack(480, 582, 481, 585);
