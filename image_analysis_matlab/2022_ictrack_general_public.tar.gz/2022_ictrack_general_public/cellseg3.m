function seg = cellseg3(im, paramfile,varargin)

%% KA modified version of cellseg function
% This function takes in the paramfile and one image (here I am taking in
% the predicted stain for segmentation).
% The image is processed through the laplacian filtering, etc.

% Note, I modified this from cellseq_KA_2chan, which I had optimized to do
% segmentation using both the CFP and YFP channels

% 3/6/19 There is an issue with the contrast adjust that I need to change
% for this to work with the predicted images

%% HYK modifications
% simplified routine, removed additional image opening steps
% adjusted low contrast and high contrast values, to exclude noise
% saturate foreground pixdels


%% Show process or not
show_process = false;    

%% load and unpack parameters
p = load(paramfile);
mindist = p.mindist;   % minimum value for the watershed minima
mindist_first = p.mindist_first;

%% lowered this contrast adjustment value to pick up dimmer edges
nstd = p.nstd;     

%% this is the upper contrast cutoff for the predicted image:  note this is a hard-coded value
high_in = p.high_in;    %% 11/28/19 - set a hard upper threshold, may need to vary depending on segmentation at other values


minsize = p.minsize;   % minimum size of a cell
maxsize = p.maxsize; % maximum size of a cell

maxecc = p.maxecc;    % the maximum eccentricity of a cell
unsharp_size = p.unsharp_size;  % 'size' of the unsharp filter
unsharp_alpha = p.unsharp_alpha;  % degree of unsharp filtering between 0.2 and 0.9

%% set laplace cutoff to to pick up the dimmest possible edges 
laplace_cutoff = 0;   % HYK hard-coded laplace cutoff 11/28/2019

gauss_size = p.gauss_size; %size of gaussian blur
gauss_std = p.gauss_std; %stdev of gaussian blur
close1 = p.close1; %size of diamond for first close operation (after laplacian threshholding)
open1 = p.open1; %size of disk to use for open operation to remove debris
max_hull_area = p.max_hull_area;
min_hull_ratio = p.min_hull_ratio;
max_ratio = p.max_ratio;
high_in_thresh = p.high_in_thresh;


%% define image analysis filters
h1 = fspecial('gaussian',gauss_size, gauss_std); % 2D guassian filter
h2 = fspecial('laplacian', unsharp_alpha);  % what is this shape factor?  worry about this later.
se1 = strel('diamond',close1);
se2 = strel('disk', open1);   % removing debris

%% start processing routine

im = double(im);  % convert to double
original = im; %save unprocessed image for regionprops calcs
   
%make list of processing functions for use in for loop
funcs = {@(im) imfilter(im,h1), 'Gaussian Filter';
         @(im) contrast_adjust(im,nstd, high_in), 'Contrast Adjust'; %see function defined below
         @(im) imfilter(im,h2), 'Laplacian';
         @(im) (im < laplace_cutoff), 'Laplace < cutoff';
         @(im) imclose(im, se1), 'Close';
         @(im) imfill(im,'holes'), 'Fill Holes';
         @(im) imclearborder(im,8), 'Clear Border';
         @(im) imopen(im, se2), 'Open';
         @(im) bwmorph(im,'clean'), 'Clean';  % remove isolated pixels
         @(im) watershed_plus(im,mindist), 'Watershed Separation'; %see function defined below
         %@(im) semiconvhull(im,max_hull_area,min_hull_ratio), 'Hull'; %see function defined below - remove for segtrack6

         @(im) bwlabel(im), 'Label Objects';
         @(im) filter_obj(im,original,minsize,maxsize,max_ratio), 'Objects Filtered'; %see function defined below
         };
     
N_steps = size(funcs,1);

 
if ~isempty(varargin)
    show_process = varargin{1};
end


if show_process
    figure()
    %sub_cols = 2; %ceil(sqrt(N_steps+1));
    %sub_rows = 3; %ceil((N_steps+1)/sub_cols);
    %subplot(sub_rows,sub_cols,1)
    imshow(im,[min(im(:)),max(im(:))])
    title('Original Image')
end

for i = 1:size(funcs,1)
    fun = funcs{i,1};
    im = fun(im);
    if show_process
        figure(i)
        %subplot(sub_rows,sub_cols,i+1)
        imshow(im,[double(min(im(:))),double(max(im(:)))])
        title(funcs{i,2})
    end
end
seg = im; %this is now the fully segmented image

end

% contrast adjustment on the gaussian filtered image
function im_out = contrast_adjust(im,nstd_low, high_in)

low_in = quantile(im(:), .5) + nstd_low*(quantile(im(:),0.75) - quantile(im(:),0.5))

high_in = 2;

%high_in_max =  double(max(im(:)))    % higest intensity input value to guarantee cell
%high_in_max = quantile(im(:), .5) + nstd_high*(quantile(im(:),0.75) - quantile(im(:),0.5))
%high_in_max =  quantile(im(:), foreground_quantile);
%high_in = max(high_in_max, high_in_thresh) % make sure high_in is above specified threshold to avoid segmenting noise

if (low_in > high_in)
    im_out = zeros(size(im));
    return
end

im_out = imadjust(im./high_in,[low_in/high_in; 1],[0 ; 1]);
end




% % contrast adjustment on the gaussian filtered image (this is Kueh's
% % method, not WW's)
% function im_out = contrast_adjust(im,nstd,high_in_thresh)
% [n,x] = hist(double(im(:)),300);
% fitresult = gauss1(x',n');
% low_in = fitresult.b1 + nstd*fitresult.c1;
% high_in =  double(max(im(:)));    % higest intensity input value to guarantee cell
% high_in = max(high_in, high_in_thresh); % make sure high_in is above specified threshold to avoid segmenting noise
% 
% if (low_in > high_in)
%     im_out = zeros(size(im));
%     return
% end
% 
% im_out = imadjust(im./high_in,[low_in/high_in; 1],[0 ; 1]);
% end


function seg = filter_obj(im,original,minsize,maxsize,max_ratio)
props = regionprops(im, original, 'Area','Perimeter','MajorAxisLength','MinorAxisLength','MeanIntensity'); % properties of objects

area = [props.Area]; % area of each object
select = intersect(find(area > minsize), find(area < maxsize));   % select objects of a certain size
ratio = [props.Perimeter].^(2)./[props.Area]; % perimeter squared/area ratio of each object
% [w] = wobble(i9,im); % wobble of each object
% select = intersect(select, find(myecc < maxecc));  % select objects that are not too eccentric
select = intersect(select, find(ratio < max_ratio)); % select objects that are below a certain perimeter squared/area ratio
% select = intersect(select, find(w < maxwobble)); % select objects without too much wobble
seg = ismember(im, select); % select objects within parameters from labeled objects to output
end

function seg = watershed_plus(seg,mindist)
%watershed algorithm
D = bwdist(~seg);
D = -D;
D = imhmin(D,mindist);
D(~seg) = Inf;
L = watershed(D);
seg = seg.*(L>0);
end

function im_out = semiconvhull(im,max_area,min_pr)
%get regions with small differences from hull
hull = bwconvhull(im,'objects');
diff = hull - im; %image of regions that got painted over by hull
diff_label = bwlabel(diff);
diff_props = regionprops(diff_label,'Area');
area = [diff_props.Area];
select = find(area < max_area); %get the small regions
small_regions = ismember(diff_label,select); %will subtract off of hull image later

%find regions that will not affect perimeter much if removed from hull
    %defined as regions of diff that have a low internal:total perimeter ratio
big_regions = ismember(diff_label,find(area >= max_area));
big_perim = bwperim(big_regions);
hull_perim = bwperim(hull);
big_label = bwlabel(big_perim);
%get info about the section of the perimeter of the concavities that is on the perimeter of the hull
    %area is actually perimeter because these regions are perimeters
    %mean intensity comes from hull perimeter image, so only counts pixels in the hull perimeter
    %want total pixels in union of hull perimeter and diff perimeter --> multiply mean intensity by area
surface_props = regionprops(big_label,hull_perim,'Area','MeanIntensity');
surface_perim = [surface_props.Area].*[surface_props.MeanIntensity];
ratio = surface_perim./[surface_props.Area];
select = find(ratio > min_pr); %get all diff regions that have high surface perimeter
high_exposure = ismember(big_label,select);
high_exposure = imfill(high_exposure,'holes');

im_out = hull - small_regions - high_exposure; %undo hull for regions that are small or have high exposed perimeter
end