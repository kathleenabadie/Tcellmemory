% Script to test contrast adjustment and segmentation
% 20190827

%% Enter timepoint and parameters to test
% segchannel 1 is cfp 
% segchannel 2 is yfp 
timepoint = 1781;

segchannel = 3; % cfp
segchannel2 = 2; % yfp

nstd_ch1 = 16;   % (cfp) number of standard deviations above background intensities for contrast -segchannel 1
nstd_ch2 = 3;   % (yfp) number of standard deviations above background intensities for contrast - segchannel 2

high_in_thresh_ch1 = 1000;
high_in_thresh_ch2 = 1000;

cellsize = 50; % for tophat

segfun = 'cellseg_KA_2chan_201908';  % user-written function for cell segmentation
paramfile = '/data/abadiek/Imaging/Data_and_Processsing/2019.08.08_CD8_KL_IL12_aLFA1/2019.08.08_CD8_KL_raw_ANALYZED_20190818_21-22-54/params_20190827_17-22-28.mat';

%%
% load images structure
imfile = ['imgf_' num2strn(timepoint,4) '.mat'];
load(imfile);  % loads the images structure

% extract individual channels 
im1 = double(images(segchannel).im(:,:,1,1)); 
im2 = double(images(segchannel2).im(:,:,1,1)); % KA do the same for the second seg channel
% Show original channel images
subplot(4,2,1)
imshow(im1,[min(im1(:)),max(im1(:))])
title('Original CFP')
subplot(4,2,2)
imshow(im2,[min(im2(:)),max(im2(:))])
title('Original YFP')

% tophat
im1 = imtophat(im1,strel('disk',50));
im2 = imtophat(im2,strel('disk',50));
subplot(4,2,3)
imshow(im1,[min(im1(:)),max(im1(:))])
title('tophat CFP')
subplot(4,2,4)
imshow(im2,[min(im2(:)),max(im2(:))])
title('tophat YFP')

% contrast adjust separately
im1_scaled = contrast_adj_KA_201908(im1,nstd_ch1,high_in_thresh_ch1);
im2_scaled = contrast_adj_KA_201908(im2,nstd_ch2,high_in_thresh_ch2);
subplot(4,2,5)
imshow(im1_scaled,[min(im1_scaled(:)),max(im1_scaled(:))])
title('scaled CFP, timepoint')
subplot(4,2,6)
imshow(im2_scaled,[min(im2_scaled(:)),max(im2_scaled(:))])
title('scaled YFP')

% add images and pass through segmentation
% show process
im_combined = im1_scaled + im2_scaled;
subplot(4,2,7)
imshow(im_combined,[min(im_combined(:)),max(im_combined(:))])
title('combined&scaled')

seg = feval(segfun, im_combined, paramfile, true);   % running the cell segmentation algorithm for this given image
