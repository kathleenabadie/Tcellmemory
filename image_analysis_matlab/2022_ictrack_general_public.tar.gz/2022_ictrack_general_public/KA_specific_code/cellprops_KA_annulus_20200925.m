function data = cellprops_KA_annulus_20200129(images, obj, varargin)
% FUNCTION DATA = CELLPROPS(IMAGES, OBJ) takes an input an ictrack image
% matrix IMAGE, an segmented objected OBJ, and returns a DATA structure
% containing relevant experiment-specific information about the properties
% of the cell object.
%
% Channels
% 1, BF; 2, YFP; 3, prediction
% 
%KA 3/3/20 modification: enable cellprops to run on time points that do not
%have fluorescent channel images; for these timepoints, fill fluor channel
%data fields with NaN


% % Modified 061718, HYK

%parse varargin
switch length(varargin)
    case 0
        save_images = true;
        skip_tophat = false;
    case 1
        save_images = varargin{1};
        skip_tophat = false;
    case 2
        save_images = varargin{1};
        skip_tophat = varargin{2};
end



    

% load images 
yfp = double(images(2).im);   % tcf1-yfp
pred = double(images(3).im);
[X,Y] = size(pred);    % maximum size of the image


% perform background subtraction if requested
if ~skip_tophat
    cellsize = 40;
    se = strel('disk',cellsize);
    yfp = imtophat(yfp, se);
end

% parameters and filters
bbscaling = 2.5;    % enlargement factor for bounding box
% May need to change shrinking and expanading parameters, because
% segmenation is on full cell, not nuclear fluorescence. Was previously at
% shrink = 1 and expand = 7 when marker was nuclear
shrink = 1;         % number of pixels to shrink for nuclear segmentation 
expand = 6;         % number of pixels to enlarge to get cytoplasmic boundary
                                                                                                        
%% bounding box for initial nuclear segmentation                                                         
x1 = min(obj.b(:,2));                                                                                        
x2 = max(obj.b(:,2));                                                                                        
y1 = min(obj.b(:,1));                                                                                        
y2 = max(obj.b(:,1));                                                                                       
xm = (x1+x2)/2;   % mean x position                                                                          
ym = (y1+y2)/2;   % mean y position                                                                        
xmin = max(round(xm-(xm-x1)*bbscaling),1);                                                                   
ymin = max(round(ym-(ym-y1)*bbscaling),1);                                                                   
xmax = min(round(xm+(x2-xm)*bbscaling),X);                                                                   
ymax = min(round(ym+(y2-ym)*bbscaling),Y); 


% If there are no fluorescent channel data for this object, fill data
% structures with NaN
if isempty(yfp) % if this is an object without fluor data
    data = obj.data;
    data.TCF1_YFP_cor = NaN;
    data.TCF1_YFP_cor_abs = NaN;
    data.TCF1_YFP = NaN;
    data.ymin = ymin;
    data.ymax = ymax;
    data.xmin = xmin;
    data.xmax = xmax;
else            
    %% take region of the original image                                                               
    yfp2 = yfp(ymin:ymax, xmin:xmax);                                                                                                                                                                                                                             
    seg = zeros([Y,X]);
    seg(sub2ind([Y X], obj.b(:,1), obj.b(:,2))) = 1; 
    seg2 = imfill(seg(ymin:ymax, xmin:xmax),'holes');   % filled, segmented image for nuclear segmentation


    % structuring element parameters for background subtraction
    se1 = strel('disk',3);   % disk of radius two for excluding outer fluorescence rim.
    se2 = strel('disk',6);   % disk of radius five for background estimation

    % b2 = imfill(b1,'holes');   % interior cell image
    b_small = imdilate(seg2,se1);  % segmented image for inner rim
    b_big = imdilate(seg2,se2);   % segmented image for outer rim
    b_ann = logical(b_big .* (~b_small));    % subtract the interior image from the outside

    ring_yfp = double(median(yfp2(b_ann)));  % median intensity of annulus

    nbw = logical(imerode(seg2,strel('disk',shrink)));   % nuclear mask
    cbw = logical(imdilate(seg2,strel('disk',expand)));    % cytoplasmic + nuclear mask% Do the following for both yfp and amcy

    %get old data from obj in order to not overwrite existing fields when the
    %output of this is passed to sch.addobjdata
    data = obj.data;

    data.TCF1_YFP_cor = double(median(yfp2(nbw))) - ring_yfp;

    % 7/24/19 addition, KA: 
    % also add a data field for the absolute fluorescence (corrected median x area)
    data.TCF1_YFP_cor_abs = (double(median(yfp2(nbw))) - ring_yfp)*data.area;

    data.TCF1_YFP = double(median(yfp2(nbw)));

    %save small imgaes of segmentation if requested
        %if images are saved the resulting file will be incompatible with cytometry2
    if save_images
        data.nbw = nbw;
        data.cbw = cbw;
        data.yfp2 = yfp2;
    else %if not saving images save corners of image sections
        data.ymin = ymin;
        data.ymax = ymax;
        data.xmin = xmin;
        data.xmax = xmax;
    end

% UNCOMMENT IF YOU WANT TO VIEW THESE IMAGES
%     figure(100); 
%     subplot(3,3,1); imshow(yfp2,[]); title(['TCF1-YFP = ' num2str(data.TCF1_YFP)]);
% 
% 
% 
%     subplot(3,3,2); imshow(apc2,[]); title(['CD69-APC = ' num2str(data.CD44_APC)]);
%     subplot(3,3,3); imshow(amcy2,[]); title(['Tbet-AmCyan = ' num2str(data.Tbet_AmCy)]);
%     subplot(3,3,4); imshow(nbw);title('nuclear mask');
%     subplot(3,3,5); imshow(b_ann,[]); title('annulus'); 
%     subplot(3,3,6); imshow(cbw);title('cytoplasmic mask');
% 
% 
% 
%     keyboard
%     close(100);  

end



end


