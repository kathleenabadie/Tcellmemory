function data = cellprops_KA_annulus(images, obj, varargin)
% FUNCTION DATA = CELLPROPS(IMAGES, OBJ) takes an input an ictrack image
% matrix IMAGE, an segmented objected OBJ, and returns a DATA structure
% containing relevant experiment-specific information about the properties
% of the cell object.
%
% Channels changed for 06.19 experiment 
% Channels
% 1, BF; 2, YFP; 3, CFP; 4, APC
% This CELLPROPS function is relevant for measuring the following in the CD8
% naive stimulation assay with dual color mice and using Tbet-AmCyan and
% TCF1-YFP for segmentation: TCF1-YFP (channel 2), CD62L-PE (channel 3),
% CD44-APC (channel 4), Tbet-AmCyan (channel 5)
% 


% % Modified 061718, HYK
%disp(['using annulus cellprops']);

%parse varargin
switch length(varargin)
    case 01
        save_images = true;
        skip_tophat = false;
    case 1
        save_images = varargin{1};
        skip_tophat = false;
    case 2
        save_images = varargin{1};
        skip_tophat = varargin{2};
end


% load images 
yfp = double(images(2).im);   % tcf1-yfp
pe = double(images(3).im); % cd62l-pe
amcy = double(images(5).im);   % tbet-amcyan
apc = double(images(4).im);   % cd44-apc
[X,Y] = size(yfp);    % maximum size of the image

% perform background subtraction if requested
if ~skip_tophat
    cellsize = 40;
    se = strel('disk',cellsize);
    yfp = imtophat(yfp, se);
    pe = imtophat(pe, se);
    apc = imtophat(apc, se);
    amcy = imtophat(amcy, se);
end

% parameters and filters
bbscaling = 2.5;    % enlargement factor for bounding box
% May need to change shrinking and expanading parameters, because
% segmenation is on full cell, not nuclear fluorescence. Was previously at
% shrink = 1 and expand = 7 when marker was nuclear
shrink = 1;         % number of pixels to shrink for nuclear segmentation 
expand = 6;         % number of pixels to enlarge to get cytoplasmic boundary
                                                                                                        
%% bounding box for initial nuclear segmentation                                                         
x1 = min(obj.b(:,2));                                                                                        
x2 = max(obj.b(:,2));                                                                                        
y1 = min(obj.b(:,1));                                                                                        
y2 = max(obj.b(:,1));                                                                                       
xm = (x1+x2)/2;   % mean x position                                                                          
ym = (y1+y2)/2;   % mean y position                                                                        
xmin = max(round(xm-(xm-x1)*bbscaling),1);                                                                   
ymin = max(round(ym-(ym-y1)*bbscaling),1);                                                                   
xmax = min(round(xm+(x2-xm)*bbscaling),X);                                                                   
ymax = min(round(ym+(y2-ym)*bbscaling),Y);                                                                   
                 
%% take region of the original image                                                               
yfp2 = yfp(ymin:ymax, xmin:xmax);                                                                            
%pe2 = pe(ymin:ymax, xmin:xmax);                                                                            
apc2 = apc(ymin:ymax, xmin:xmax);                                                                            
amcy2 = amcy(ymin:ymax, xmin:xmax);   
seg = zeros([Y,X]);
seg(sub2ind([Y X], obj.b(:,1), obj.b(:,2))) = 1; 
seg2 = imfill(seg(ymin:ymax, xmin:xmax),'holes');   % filled, segmented image for nuclear segmentation


% structuring element parameters for background subtraction
se1 = strel('disk',3);   % disk of radius two for excluding outer fluorescence rim.
se2 = strel('disk',6);   % disk of radius five for background estimation

% b2 = imfill(b1,'holes');   % interior cell image
b_small = imdilate(seg2,se1);  % segmented image for inner rim
b_big = imdilate(seg2,se2);   % segmented image for outer rim
b_ann = logical(b_big .* (~b_small));    % subtract the interior image from the outside

ring_yfp = double(median(yfp2(b_ann)));  % median intensity of annulus
ring_amcy = double(median(amcy2(b_ann)));  % median intensity of annulus

nbw = logical(imerode(seg2,strel('disk',shrink)));   % nuclear mask
cbw = logical(imdilate(seg2,strel('disk',expand)));    % cytoplasmic + nuclear mask% Do the following for both yfp and amcy

%get old data from obj in order to not overwrite existing fields when the
%output of this is passed to sch.addobjdata
data = obj.data;pe = double(images(3).im); % cd62l-pe


data.TCF1_YFP_cor = double(median(yfp2(nbw))) - ring_yfp;
data.Tbet_AmCy_cor = double(median(amcy2(nbw))) - ring_amcy;

% 7/24/19 addition, KA: 
% also add a data field for the absolute fluorescence (corrected median x area)
data.TCF1_YFP_cor_abs = (double(median(yfp2(nbw))) - ring_yfp)*data.area;
data.Tbet_AmCy_cor_abs = (double(median(amcy2(nbw))) - ring_amcy)*data.area;

%data.CD62L_PE = double(median(pe2(cbw)));
data.CD44_APC = double(median(apc2(cbw)));
data.TCF1_YFP = double(median(yfp2(nbw)));
data.Tbet_AmCy = double(median(amcy2(nbw)));

%save small imgaes of segmentation if requested
    %if images are saved the resulting file will be incompatible with cytometry2
if save_images
    data.nbw = nbw;
    data.cbw = cbw;
    data.yfp2 = yfp2;
    %data.pe2 = pe2;
    data.apc2 = apc2;
    data.amcy2 = amcy2;
else %if not saving images save corners of image sections
    data.ymin = ymin;
    data.ymax = ymax;
    data.xmin = xmin;
    data.xmax = xmax;
end

figure(100); 
subplot(2,3,1); imshow(yfp2,[]); title(['TCF1-YFP = ' num2str(data.TCF1_YFP)]);



%subplot(2,3,2); imshow(pe2,[]); title(['CD62L-PE = ' num2str(data.CD62L_PE)]);
subplot(2,3,2); imshow(apc2,[]); title(['CD44-APC = ' num2str(data.CD44_APC)]);
subplot(2,3,3); imshow(amcy2,[]); title(['Tbet-AmCyan = ' num2str(data.Tbet_AmCy)]);
subplot(2,3,4); imshow(nbw);title('nuclear mask');
subplot(2,3,5); imshow(b_ann,[]); title('annulus'); 
subplot(2,3,6); imshow(cbw);title('cytoplasmic mask');
close(100);  

end


