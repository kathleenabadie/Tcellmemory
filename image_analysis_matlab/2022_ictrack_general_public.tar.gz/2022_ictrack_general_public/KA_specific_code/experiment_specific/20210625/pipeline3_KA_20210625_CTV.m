function pipeline3_KA_20210625_CTV(indir, basenames, outdir, paramfile, varargin)

%% PRE-PROCESS AND TRACK IMAGES %%
%% PROCESSING STARTS
p = load(paramfile)
S = p.S;  % the number of stage positions

% load the optional argument to specify range of stage positions to process
if (~isempty(varargin))
    positions = varargin{1};  % vector listing stage positions to process
else
    positions = 1:S; 
end

% run on one position at a time
positions = 1;
i = positions    % loop over all stage positions
outdir1 = [outdir '/pos ' num2str(i)];  % output directory for the specific file offset    
preprocess_20210625_CTV(indir, basenames, outdir1, i, paramfile);  % Metamorph preprocessing
seg_KA(outdir1,paramfile);    % Cell segmentation
track3_KA(outdir1,paramfile);  % Cell tracking, based on existing segmentation

% % parallel for loop for running on multiple positions
% parfor i = positions    % loop over all stage positions
%     outdir1 = [outdir '/pos ' num2str(i)];  % output directory for the specific file offset    
%     preprocess_20210625_CTV(indir, basenames, outdir1, i, paramfile);  % Metamorph preprocessing
%     seg_KA(outdir1,paramfile);    % Cell segmentation
%     track3_KA(outdir1,paramfile);  % Cell tracking, based on existing segmentation
% end