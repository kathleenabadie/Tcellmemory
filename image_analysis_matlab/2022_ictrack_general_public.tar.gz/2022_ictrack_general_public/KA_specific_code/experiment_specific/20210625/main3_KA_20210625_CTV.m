
% script for running the

% Use for analyzing on Linux
indir = {'/data/abadiek/Imaging/Data_and_Processsing/20210628_CD8_D3_sort/20210628_CD8_D3_sort_raw'};

basenames = {'20210628_D3'}

% Use this one for full pipeline analysis 
outdir = [indir{1} '_ANALYZED_' datestr(datetime('now'),'yyyymmdd_HH-MM-SS')];

% Use this for analyzing a specific already pre-processed dataset 
% outdir = [indir{1} '_ANALYZED_20210810_21-38-02']

% generate parameter file for image procesing.
mkdir(outdir)
paramfile = [outdir '/params_' datestr(datetime('now'),'yyyymmdd_HH-MM-SS') '.mat'];

% Use for analyzing a specific already pre-processed dataset with same
% params file
%paramfile = [outdir '/params_20200225_10-32-16.mat'];

makeparams_KA_20210625_CTV(paramfile);
pipeline3_KA_20210625_CTV(indir, basenames, outdir, paramfile);