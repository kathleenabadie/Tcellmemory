dirname = '/data/abadiek/Imaging/Data_and_Processsing/20210628_CD8_D3_sort/20210628_CD8_D3_sort_raw_ANALYZED_20210810_21-38-02/';
%pos = 'pos 39';
%positions = ["pos 28", "pos 30", "pos 32", "pos 34", "pos 35", "pos 36", "pos 39", "pos 40", "pos 41", "pos 42"]
%positions = ["pos 28", "pos 30", "pos 32", "pos 34", "pos 35", "pos 36", "pos 37", "pos 39", "pos 40", "pos 41", "pos 42", "pos 44", "pos 45", "pos 47", "pos 48", "pos 49", "pos 50", "pos 51", "pos 65", "pos 75", "pos 76"]
positions = ["pos 28", "pos 30", "pos 32"]
filename = 'segprop.mat'
outfolder = '/data/abadiek/Imaging/Data_and_Processsing/20210628_CD8_D3_sort/20210628_CD8_D3_sort_raw_ANALYZED_20210810_21-38-02/YFP_hist_select/';
tp_int = 5 %min

for i = 1:length(positions)
    pos = positions(i)
    
    % run function to generate timepoint by YFP ave intensity vectors
    [tp, val] = time_YFP_hist(dirname, pos, filename);


    tp = tp(val>0);
    val = val(val>0);

    % convert to hours
    tp = (tp*5)/60;


    figure(1)
    scatter(tp,val)
    set(gca,'yscale','log')
    ylim([10,10000])

    val_log = log10(val);

    figure(2)
    scatter(tp,val_log)
    ylim([1,4])

    pos = convertStringsToChars(pos);
    figname = strcat(outfolder, pos(~isspace(pos)), '_scatter', '.pdf');
    figure(2), 
    %print(figname, '-dpdf')



    figure(3)
    X = [tp',val_log'];
    %hist3(X,'CdataMode', 'auto')
    hist3(X,'Nbins',[100,100],'FaceColor','interp','CDataMode','auto')
    %hist3(X,'Ctrs',centers)
    view(2)
    colorbar
    xlabel('timepoint')
    ylabel('average intensity')
    %ylim([1,max(val_log)])
    ylim([0,3.5])
    title(pos)

    figname = strcat(outfolder, pos(~isspace(pos)), '_hist_100bin','.pdf');
    figure(3), 
    print(figname, '-dpdf')
end