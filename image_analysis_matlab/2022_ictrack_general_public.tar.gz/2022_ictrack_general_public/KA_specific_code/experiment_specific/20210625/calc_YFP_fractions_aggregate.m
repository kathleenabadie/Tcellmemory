close all
clear all

dirname = '/data/abadiek/Imaging/Data_and_Processsing/20210628_CD8_D3_sort/20210628_CD8_D3_sort_raw_ANALYZED_20210810_21-38-02/';
filename = 'segprop.mat'
outfolder = '/data/abadiek/Imaging/Data_and_Processsing/20210628_CD8_D3_sort/20210628_CD8_D3_sort_raw_ANALYZED_20210810_21-38-02/YFP_frac/';
tp_int = 5; %min
window = 5;
early_window = 25;
n_std = 2;
pos_thresh = 0.075;

positions = load([outfolder 'react_pos.mat']);
positions = positions.react_pos;



% go through each position
pos_tp_pos_array = zeros(length(positions), 258);
    pos_tp_neg_array = zeros(length(positions), 258);
for i = 1:length(positions)
    pos = positions(i)
    
    % run function to generate timepoint by YFP ave intensity vectors
    [tp, val] = time_YFP_hist(dirname, pos, filename);
    
    pos = convertStringsToChars(pos); % convert pos to char for figure naming 
    
    % remove nan (non fluor timepoints)
    tp_with_bf = tp; % store original timepoint vector just to count objects in each timepoint
    tp_with_bf = (tp_with_bf*5)/60; % convert to hours
    tp = tp(~isnan(val));
    val = val(~isnan(val));

    % remove negative values 
    tp = tp(val>0);
    val = val(val>0);

    % convert to hours
    tp = (tp*5)/60;
    
    % take log of yfp vals
    val_log = log10(val);
    
    % Get the distribution of YFP log vals from the first hours of the movie
    early_val = val_log(tp < early_window);
    % set yfp gate
    yfp_gate = mean(early_val) + n_std*std(early_val);
     
    % get vector of unique timepoints
    tp_uni = unique(tp);
    if i==1
        tp_uni_std = tp_uni;
    end
    
    % go through each timepoint and calculate YFP+ fraction 
    % first, intialize vectors to store 
    n_pos_vec = NaN * ones(length(tp_uni),1);
    n_neg_vec = NaN * ones(length(tp_uni),1);
    for j = 1:length(tp_uni)
        
        t = tp_uni(j);
        
        % get object yfp values corresponding to unique timepoint t
        n_obj = sum(tp == t);
        val_t = val_log(tp == t);
        n_pos = sum(val_t > yfp_gate);
        n_neg = sum(val_t <= yfp_gate);
        n_pos_vec(j) = n_pos;
        n_neg_vec(j) = n_neg;

    end
    
    tp_uni_match = ismember(tp_uni_std, tp_uni);
    
    
    pos_tp_pos_array(i, tp_uni_match) = n_pos_vec';
    pos_tp_neg_array(i, tp_uni_match) = n_neg_vec';
    
end

% aggregate positions
agg_pos = sum(pos_tp_pos_array, 1);
agg_neg = sum(pos_tp_neg_array, 1);

f_pos_vec = agg_pos ./ (agg_pos + agg_neg);

% smoothed frac over time
xx = linspace(0,max(tp_uni),1000);
yy = smooth(f_pos_vec, 20);
    
%  plot 
figure(1)
scatter(tp_uni, f_pos_vec, '.', 'k'); hold on
%plot(tp_uni,yy, 'k'); hold off
plot(tp_uni,yy, 'k', 'LineWidth', 2); hold off
ylim([-.05,1])
xlim([0,90])
xticks([0, 20, 40, 60, 80])
yticks([0, 0.2, 0.4, 0.6, 0.8])
ax = gca; ax.FontSize = 32; ax.LineWidth=2;
   
% print
figname = strcat(outfolder, 'YFP_pos_react_aggregate','.pdf');
print(figure(1),figname, '-dpdf')


% Define Start points, fit-function and fit curve
x0 = [.8 .5 60]; 
x = tp_uni';
y = f_pos_vec';
fitfun = fittype( @(A, v, tau, x) A./(1 + exp(-v*(x-tau))) );
[fitted_curve,gof] = fit(x,y,fitfun,'StartPoint',x0);
% Save the coeffiecient values for a,b,c and d in a vector
coeffvals = coeffvalues(fitted_curve);
% Plot results
figure(2)
scatter(x, y, '.', 'k')
hold on
plot(x,fitted_curve(x),'r', 'LineWidth', 2)
hold off
ylim([-.05,1])
xlim([0,90])
xticks([0, 20, 40, 60, 80])
yticks([0, 0.2, 0.4, 0.6, 0.8])
ax = gca; ax.FontSize = 32;
% print
figname = strcat(outfolder, 'YFP_pos_react_aggregate_fit','.pdf');
print(figure(2),figname, '-dpdf')

save([outfolder 'coeffvals'], 'coeffvals');

