function makeparams_KA_20210625_CTV(outfile) 

%% MAKEPARAMS(OUTFILE) generates a parameter file with the filename OUTFILE 
%% for subsequent image conversion, segmentation and tracking for the 
%% immune cell analysis suite.

%% Image acquisition parameters 
S = 102;    % total number of stage positions
X = 1080;   % the number of row pixels
Y = 1080;   % the number of column pixels
Z = 1;     % the number of z-sections
M = 1;  %sqrt(S); % the number of row tiles
N = 1;   %sqrt(S); % the number of column tiles

segchannel = 3;   % fluorescence channel used for segmentation
datachannel = 3;  % fluorescence channel used to set 'skipping' channel for image viewing

correct = [];

C(1).cR = 255;   % BF channel parameters
C(1).cG = 255;
C(1).cB = 255;
C(1).doz = 0;
C(1).zslices = 1;
C(1).tlist = [];
C(1).min = 300;
C(1).max = 25000; 
C(1).flatten = false; %do not to tophat on BF

C(2).cR = 255;  % Tcf1-YFP (LDI 528) parameters
C(2).cG = 255;
C(2).cB = 0;
C(2).doz = 1;
C(2).zslices = 1;
C(2).correct = correct;
C(2).tlist = [];
C(2).min = 200; % change from 30 to 200 for LDI (6/19/19)
C(2).max = 2000; % change for LDI
C(2).flatten = true;

C(3).cR = 225;   % CTV prediction Purple 
C(3).cG = 0;
C(3).cB = 255;
C(3).doz = 1;  
C(3).zslices = 1;
C(3).correct = correct;
C(3).tlist = [];
C(3).min = 1;
C(3).max = 10;
C(3).flatten = true;

%% Preprocessing parameters
cellsize = 50; %cell size used for tophat correction during preprocessing


%% MATLAB function for cell segmentation
segfun = 'cellseg3_20210628_hard_lowin_highin';  % user-written function for cell segmentation
cellprops = 'cellprops_KA_annulus_20200925';   % user-written function 

calc_ratios = false; %calculate the nuclear:cytoplasmic ratios during segmentation
skip_tophat = true; %skip tophat during the cellprops calculation
                        %only do this if flatten = true for all fluorescent channels

%% Segmentation Parameters
mindist = 3;   % minimum value for the watershed minima
mindist_first = 7; % less aggressive watershed for first round (before fill holes)
nstd = 5;   % number of standard deviations above background intensities for contrast; changed 6 to 5 20210809
high_in = 2; % changed to 2  KA 02/18/20
minsize =300;   % minimum size of a cell - changed to 600  KA 02/18/20 ; changed to 300 08/17/21
maxsize = 4000; % maximum size of a cell
maxecc = 4;    % the maximum eccentricity of a cell
unsharp_size = 7;  % 'size' of the unsharp filter
unsharp_alpha = 0.8;  % degree of unsharp filtering between 0.2 and 0.9
laplace_cutoff = 0; %maximum acceptible value of laplacian
gauss_size = 10; %size of gaussian blur
gauss_std = 5; %stdev of gaussian blur
close1 = 1; %size of diamond for first close operation (after laplacian threshholding), integer
open1 = 5; %size of disk to use for open operation to remove debris, integer
max_hull_area = 25; %maximum area of concavities to allow in convex hull calculation
min_hull_ratio = 0.4; %minimum exposed:total perimeter ratio of concavities to allow in convex hull calulation
max_ratio = 30; % maximum ratio of perimeter squared over area to prevent long skinny cells
high_in_thresh = 200;



%% Object tracking parameters
Cxy = 100;    % maximum travel distance
Carea = 1;   % maximal log2 fold change in area %KA relaxed from 0.6 to 1 20201007
%Cf = 0.5;     % maximal fold change in red or green fluorescence level
maxskip = 1; % the total possible number of omitted frames
% cell division tracking parameters
dr_dist = 30;  % maximum distance in pixels of the parent cell to both of the daughters must be from the parent (KA changed from 20 to 30 20201007)
dr_avgdist = 10;  % maximum distance in pixels of the parent cell to averaged centroid distances of the two daughters
f_sizesum = 0.26;   % maximum fold difference between parent area and sum of daughter areas

%% outfile filenames:
segfile = 'segment_080921.mat';    % name for MATLAB data file containing all the segmentation data
segtrackfile = 'segtrack_080921.mat';   % name for MATLAB file contaning segmentation and tracking data


save(outfile);
