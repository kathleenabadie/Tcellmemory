function makeparams_KA_20200129_predict(outfile) 

%% MAKEPARAMS(OUTFILE) generates a parameter file with the filename OUTFILE 
%% for subsequent image conversion, segmentation and tracking for the 
%% immune cell analysis suite.
%% MJW 9/19/2016 - changed tracking parameters.

%% Image acquisition parameters 
S = 158;    % total number of stage positions
X = 1080;   % the number of row pixels
Y = 1080;   % the number of column pixels
Z = 1;     % the number of z-sections
M = 1;  %sqrt(S); % the number of row tiles
N = 1;   %sqrt(S); % the number of column tiles

segchannel = 5;   % fluorescence channel used for segmentation
datachannel = 5;  % fluorescence channel used to set 'skipping' channel for image viewing

correct = [];

C(1).cR = 255;   % BF channel parameters
C(1).cG = 255;
C(1).cB = 255;
C(1).doz = 0;
C(1).zslices = 1;
C(1).tlist = [];
C(1).min = 300;
C(1).max = 15000; 
C(1).flatten = false; %do not to tophat on BF

C(2).cR = 255;  % Tcf1-YFP (LDI 528) parameters
C(2).cG = 255;
C(2).cB = 0;
C(2).doz = 1;
C(2).zslices = 1;
C(2).correct = correct;
C(2).tlist = [];
C(2).min = 200; % change from 30 to 200 for LDI (6/19/19)
C(2).max = 1000; % change for LDI
C(2).flatten = true;

C(3).cR = 0;   % Tbet-CFP (LDI 445) Teal
C(3).cG = 255;
C(3).cB = 255;
C(3).doz = 1;  
C(3).zslices = 1;
C(3).correct = correct;
C(3).tlist = [];
C(3).min = 200;% change from 30 to 200 for LDI (9/10/19)
C(3).max = 5000;% increased for LDI
C(3).flatten = true;

C(4).cR = 0;   % CD69-APC (LDI 640) blue
C(4).cG = 0;
C(4).cB = 255;
C(4).doz = 1;  
C(4).zslices = 1;
C(4).correct = correct;
C(4).tlist = [];
C(4).min = 200; % change from 30 to 200 for LDI (9/10/19)
C(4).max = 1000; % change from 500 to 20000 for LDI (9/10/19)
C(4).flatten = true;

C(5).cR = 225;   % CTV prediction Purple 
C(5).cG = 0;
C(5).cB = 255;
C(5).doz = 1;  
C(5).zslices = 1;
C(5).correct = correct;
C(5).tlist = [];
C(5).min = 1;
C(5).max = 10;
C(5).flatten = true;

%% Preprocessing parameters
cellsize = 50; %cell size used for tophat correction during preprocessing


%% MATLAB function for cell segmentation
segfun = 'cellseg3';  % user-written function for cell segmentation
cellprops = 'cellprops_KA_annulus_20200129';   % user-written function 

calc_ratios = false; %calculate the nuclear:cytoplasmic ratios during segmentation
skip_tophat = true; %skip tophat during the cellprops calculation
                        %only do this if flatten = true for all fluorescent channels

%% Segmentation Parameters
mindist = 3;   % minimum value for the watershed minima
mindist_first = 7; % less aggressive watershed for first round (before fill holes)
nstd = 5;   % number of standard deviations above background intensities for contrast; changed to 6  KA 02/18/20
high_in = 2; % changed to 2  KA 02/18/20
minsize =600;   % minimum size of a cell - changed to 600  KA 02/18/20
maxsize = 4000; % maximum size of a cell
maxecc = 4;    % the maximum eccentricity of a cell
unsharp_size = 7;  % 'size' of the unsharp filter
unsharp_alpha = 0.8;  % degree of unsharp filtering between 0.2 and 0.9
laplace_cutoff = -0.0005; %maximum acceptible value of laplacian
gauss_size = 10; %size of gaussian blur
gauss_std = 5; %stdev of gaussian blur
close1 = 1; %size of diamond for first close operation (after laplacian threshholding), integer
open1 = 5; %size of disk to use for open operation to remove debris, integer
max_hull_area = 25; %maximum area of concavities to allow in convex hull calculation
min_hull_ratio = 0.4; %minimum exposed:total perimeter ratio of concavities to allow in convex hull calulation
max_ratio = 30; % maximum ratio of perimeter squared over area to prevent long skinny cells
high_in_thresh = 200;



%% Object tracking parameters
Cxy = 100;    % maximum travel distance
Carea = 0.6;   % maximal fold change in area
Cf = 0.5;     % maximal fold change in red or green fluorescence level
maxskip = 1; % the total possible number of omitted frames

%% outfile filenames:
segfile = 'segment_0319.mat';    % name for MATLAB data file containing all the segmentation data
segtrackfile = 'segtrack_0319.mat';   % name for MATLAB file contaning segmentation and tracking data


save(outfile);