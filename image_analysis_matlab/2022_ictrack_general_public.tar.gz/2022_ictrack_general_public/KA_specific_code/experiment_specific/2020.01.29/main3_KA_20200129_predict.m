
% script for running ictrack analysis pipeline

% Use for analyzing on Linux
indir = {'/data/abadiek/Imaging/Data_and_Processsing/20200129_CD8_KL_infl/20200129_CD8_KL_infl_raw'};

% Use for analyzing on Windows
% indir = {'D:\abadiek_old_copy\Imaging\Data_and_Processsing\20200129_CD8_KL_infl\20200129_CD8_KL_infl_raw'};

basenames = {'20200129', '20200129_v2'}

% Use this one for full pipeline analysis 
outdir = [indir{1} '_ANALYZED_' datestr(datetime('now'),'yyyymmdd_HH-MM-SS')];

% Use this for analyzing a specific already pre-processed dataset 
% outdir = [indir{1} '_ANALYZED_20200225_01-41-21']

% generate parameter file for image procesing.
mkdir(outdir)
paramfile = [outdir '/params_' datestr(datetime('now'),'yyyymmdd_HH-MM-SS') '.mat'];

%Use for analyzing a specific already pre-processed dataset
%paramfile = [outdir '/params_20200225_10-32-16.mat'];

makeparams_KA_20200129_predict(paramfile);
pipeline3_KA_20200129(indir, basenames, outdir, paramfile);