function show_process(dir,T)
load([dir '/segtrack.mat'])
load([dir '/acq.mat'])
p = load('params.mat');

segchannel = p.segchannel;

images = load([dir '/imgf_' num2strn(T,4) '.mat']);
images = images(1).images; %unpack struct that MATLAB makes by default with load
im = images(segchannel).im(:,:,1,1,1); %get image used for segmentation

fname = [dir '/seg_process_' num2str(T) '.mat'];
seg = cellseg_TRP3(im,fname);

load(fname)
for i = 1:length(im_steps)
    subplot(4,4,i)
    step = im_steps{i,1};
    imshow(step,[min(step(:));max(step(:))])
    title(im_steps{i,2})
end

delete(fname)

end