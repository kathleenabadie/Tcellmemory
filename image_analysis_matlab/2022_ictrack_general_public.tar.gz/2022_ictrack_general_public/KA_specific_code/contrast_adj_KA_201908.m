

function im_out = contrast_adj_KA_201908(im,nstd,high_in_thresh)
[nn,x] = hist(double(im(:)),300);
fitresult = gauss1(x',nn');
low_in = fitresult.b1 + nstd*fitresult.c1;

high_in =  double(max(im(:)));    % higest intensity input value to guarantee cell
high_in = max(high_in, high_in_thresh); % make sure high_in is above specified threshold to avoid segmenting noise
if (low_in > high_in)
    im_out = zeros(size(im));
    return
end
im_out = imadjust(im./high_in,[low_in/high_in; 1],[0 ; 1]);
end