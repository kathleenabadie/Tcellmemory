function display_seg(dir,show)
%load relevant variables
load([dir '/segtrack.mat'])
load([dir '/acq.mat'])
p = load('params.mat');

segchannel = p.segchannel;
C = acq.C;
Z = C(segchannel).zslices;
M = acq.M;
N = acq.N;
T = acq.T;
X = acq.X;
Y = acq.Y;
tlist = C(segchannel).tlist;

box_size = 100; %radius of box to draw around segmented object
h = fspecial('gaussian',[7 7], 3);

figure(1)
if show
    figure(2)
end

ind = 1;
for i = 1:T
    if tlist(i)
        images = load([dir '/imgf_' num2strn(i,4) '.mat']);
        images = images(1).images; %unpack struct that MATLAB makes by default with load
        
        im = images(segchannel).im(:,:,1,1,1); %get image used for segmentation
        
        %get contrast settings
        low_in = double(min(im(:)));%double(quantile(obj_im(:), .5) + 1*(quantile(obj_im(:),0.75) - quantile(obj_im(:),0.5)));
        high_in =  double(max(im(:)));
        
        im_rgb = double(cat(3,im,im,im)); %still grayscale but will be used to add colored cell borders on single object images        
        im_sz = size(im);
        
        objs = objects(ind); %get structure with all objects in this image
        N_objs = length(objs.obj);
        subplot_dims = [ceil(sqrt(N_objs)),ceil(sqrt(N_objs))];
        for o = 1:N_objs
            obj = objs.obj(o); %this is a single cell as identified by the segmentation process
            border_locs = obj.b;
            
            x = round(obj.x);
            y = round(obj.y);
            x_min = max(x - box_size,1);
            x_max = min(x + box_size,im_sz(2));
            y_min = max(y - box_size,1);
            y_max = min(y + box_size,im_sz(1));
                        
            im_rgb_copy = im_rgb(:,:,:); %copy to avoid displaying this border in images for other nearby cells
            for p = 1:length(border_locs)
                im_rgb_copy(border_locs(p,1),border_locs(p,2),1) = max(im(:)); %red border for object
                im_rgb_copy(border_locs(p,1),border_locs(p,2),2) = 0;
                im_rgb_copy(border_locs(p,1),border_locs(p,2),3) = 0;
                
                full_im(border_locs(p,1),border_locs(p,2),1) = 1; %red border for object
                full_im(border_locs(p,1),border_locs(p,2),2) = 0;
                full_im(border_locs(p,1),border_locs(p,2),3) = 0;
            end
            
            obj_im = double(im_rgb_copy(y_min:y_max,x_min:x_max,:)); %get region of image containing object
            
            %adjust contrast
            obj_im = imadjust(obj_im./high_in,[low_in/high_in; 1]);
            
            figure(1)
            subplot(subplot_dims(1),subplot_dims(2),o)
            imshow(obj_im)
            title(['T: ' num2str(i) ', obj: ' num2str(o)])
            
        end
        ind = ind+1;
        drawnow
        
        if show
            figure(2)
            show_process(dir,i)
        end
        
        waitforbuttonpress;
        figure(1)
        clf
    end
    
end
end