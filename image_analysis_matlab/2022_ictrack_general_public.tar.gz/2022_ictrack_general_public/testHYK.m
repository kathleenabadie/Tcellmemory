% testing the image segmentation script across different timepoints
paramfile = 'params_20191119_00-17-35.mat';
t = [3 100 400 800 1000];
for i = 1:length(t)

    filename = ['imgf_' num2strn(t(i),4) '.mat'];   % filename
    load(filename);   % load the image file;
    im = images(5).im;   % load the predicted brightfield image
   
    data(i).seg = cellseg3(im,  paramfile);
    pause;   % pause to review images
    close all;
end
