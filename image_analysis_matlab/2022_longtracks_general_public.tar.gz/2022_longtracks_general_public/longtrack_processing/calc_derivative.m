load('lin_1202_5_trlong.mat');   % this is the saved output from my previous version of the longtracks file

close all;

m = 1;   % lineage number
n = 9;   % track number 
span = 23;   % the span of data points for data smoothing


t = lin(m).trlong(n).t;   % load and analyze a single time trace
data.tbet = lin(m).trlong(n).tbet;  % continuized tbet intensities
data.tcf1 = lin(m).trlong(n).tcf1;  % continuized tcf1 intensities

fieldnames = {'tbet','tcf1'};   % these are the fieldnames

for i = 1:length(fieldnames)
    y = data.(fieldnames{i});   % load the desire intensity level
    ys = smooth(t,y,span,'rlowess');    % linear fitting centered on data point
    
    figure(i)
    subplot(3,1,1);  title('intensities');
    plot(t,y,'r.'); hold on;
    plot(t,ys,'k');
    xlabel('time (hours)');
    ylabel([fieldnames{i} ' intensity']);   % the raw and smoothed values
    
    dydt = diff(ys)'./diff(t);
    
    subplot(3,1,2);
    plot(t(1:end-1), dydt);   % the first derivative
    xlabel('time (hours)');
    ylabel(['promoter activity (dydt)']);
    
    subplot(3,1,3); 
    hist(dydt,30);
    xlabel('synthesis rate');
    ylabel('frequency');
end
    
    



