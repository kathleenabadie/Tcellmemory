function save_trs(dirname, outdir, filenames)
%%
% This function goes through trlong.mat files that may contain multiple
% fields for each lin and extracts only the trs field. It then saves a
% this as a trs.mat file in a separate folder.

%%
mkdir(outdir)
for h = 1:length(filenames)
    if ~contains(filenames(h).name, 'trlong') % make sure only looping through trlong files
        continue
    end
    clear('lin');               % clear the previously loaded lin structure, if exists
    full_filename = strcat(dirname,filenames(h).name);
    file = load(full_filename);
    for i = 1:length(file.lin)
        lin(i).trs = file.lin(i).trs;
    end
    
   % Save data
    % first define new filename to use for saving to designate trs status
    new_filename = split(string(filenames(h).name), ".");
    new_filename = new_filename(1);
    new_filename = strcat(new_filename, '_trs.mat');
    save(strcat(outdir, new_filename), 'lin');    
end

end