function calc_derivative_all(dirname, outdir, filenames)
% This function calculates and plots histograms for the following:
% TCF1 promoter activity
% Tbet promoter activity
% Div 1 time
% Average cell cycle time after Div 1 



%%  USER INPUT

span = [40,80];   % the span of data points for data smoothing; indexing corresponds to fieldnames
N = 5; % window for median filtering prior to smoothing
t_begin = 0;   % only analyze data earlier than this time point
t_end = 300;

fieldnames = {'tbet','tcf1'};   % these are the fieldnames

% histogram plotting parameters
th = 10000;
bins = 50;
hbins = 3:0.03:6;

%%
output.tbet_hist = [];
output.tcf1_hist = [];
output.t_div1_hist = [];
output.ave_cell_cyc = [];

for h = 1:length(filenames)
    if ~contains(filenames(h).name, 'trlong') % make sure only looping through trlong files
        continue
    end
    clear('lin');               % clear the previously loaded lin structure, if exists
    full_filename = strcat(dirname,filenames(h).name);
    file = load(full_filename);

    for i = 1:length(file.lin)
        for j = 1:length(file.lin(i).trlong)
            % get the time of the first division
            if ~isempty(file.lin(i).trlong(j).divtime)
                t_div1 = file.lin(i).trlong(j).divtime(1); 
                ave_cell_cyc = mean(diff(file.lin(i).trlong(j).divtime(2:end)));
                output.ave_cell_cyc = [output.ave_cell_cyc ave_cell_cyc];
            end
            
            t = file.lin(i).trlong(j).t;
            if t <= 1 % KA 3/18/20 added to prevent smoothing error for cell with only one timepoint
                continue
            end
            data.tbet = file.lin(i).trlong(j).tbet;  % continuized tbet intensities
            data.tcf1 = file.lin(i).trlong(j).tcf1;  % continuized tcf1 intensities

            ind = union(find(t < t_begin), find(t > t_end))   ;  % find all the indices to discard
            t(ind) = [];
            data.tbet(ind) = [];
            data.tcf1(ind) = [];


            for k = 1:length(fieldnames)
                y = data.(fieldnames{k});   % load the desire intensity level
%                 windowSize = span(k); 
%                 b = (1/windowSize)*ones(1,windowSize);
%                 a = 1;
%                 ys = filter(b,a,y);
%                 dydt = diff(ys)./diff(t);
                y_filt = medfilt1(y,N,'omitnan','truncate');
                ys = smooth(t,y_filt,span(k),'lowess');    % linear fitting centered on data point
%                 ys_midsmooth = smooth(t,y_filt,60,'lowess');
%                 ys_extrasmooth = smooth(t,y_filt,80,'lowess');
                dydt = diff(ys)'./diff(t);
%                 dydt_midsmooth = diff(ys_midsmooth)'./diff(t);
%                 dydt_extrasmooth = diff(ys_extrasmooth)'./diff(t);
                
                % save smoothed data and derivatives back to trlong structure
                file.lin(i).trlong(j).(strcat((fieldnames{k}), '_smooth')) = ys';
                file.lin(i).trlong(j).(strcat((fieldnames{k}), '_deriv')) = dydt;
                
                %Output figures to see how smoothing is doing - comment
                %out otherwise
%                 figure(100)
%                 plot(t,y)
%                 hold on
%                 plot(t,y_filt,'b.')
%                 hold on
%                 plot(t,ys, 'r.')
%                 hold on
%                 plot(t,ys_midsmooth, 'm.')
%                 hold on
%                 plot(t,ys_extrasmooth, 'g.')
%                 title(fieldnames{k})
%                 ylabel('real and smoothed intensity')
%                 figure(101)             
%                 plot(t(1:end-1), dydt, 'r.')
%                 hold on
%                 plot(t(1:end-1), dydt_midsmooth, 'm.')
%                 hold on
%                 plot(t(1:end-1), dydt_extrasmooth, 'g.')
%                 ylabel('derivative')
%                 title(fieldnames{k})
%                 close all
                
                
                % output for histogram
                output.([fieldnames{k} '_hist']) = [output.([fieldnames{k} '_hist']) dydt];

            end
        end
        output.t_div1_hist = [output.t_div1_hist t_div1];
    end
%% Save data
% Save over trlong data files with with additional data fields
lin = file.lin;
save([outdir '/tracks/' filenames(h).name], 'lin');    
end

tbet_pa = output.tbet_hist;
tcf1_pa =output.tcf1_hist;
t_div1_pa = output.t_div1_hist; 
ave_cell_cyc_pa = output.ave_cell_cyc;





%% Make histogram plots
subplot(3,3,1); hist(tbet_pa, bins); xlabel('Tbet promoter activity');
subplot(3,3,2); hist(tcf1_pa, bins); xlabel('TCF1 promoter activity');

% plotting the data on a log scale

tbet_pa2 = tbet_pa + th;    % add the threshold value 
tcf1_pa2 = tcf1_pa + th;

tbet_pa2(find(tbet_pa2<1)) = 1;      %find the small values and set them to one
tcf1_pa2(find(tcf1_pa2<1)) = 1;      %find the negative values and set them to one

tbet_tcf1_rat_pa2 = tbet_pa2./tcf1_pa2; 

log_tbet_pa = log10(tbet_pa2);        % take the logarithm of the values 
log_tcf1_pa = log10(tcf1_pa2);

subplot(3,3,3); hist(log_tbet_pa,hbins); xlabel('log of Tbet promoter activity'); set(gca, 'XLim', [3.5 6]);
subplot(3,3,4); hist(log_tcf1_pa,hbins); xlabel('log of TCF1 promoter activity'); set(gca, 'XLim', [3.5 6]);

% plot time of div1 histogram
subplot(3,3,5); histogram(t_div1_pa, bins); xlabel('div1 time (hrs)'); set(gca, 'XLim', [0 75]);
% plot ave cell cycle time histogram
subplot(3,3,6); histogram(ave_cell_cyc_pa, bins); xlabel('average cell cycle time (hrs)'); set(gca, 'XLim', [0 50]);

subplot(3,3,7); histogram(log(tbet_tcf1_rat_pa2)); xlabel('log of Tbet/Tcf1 promoter activity ratio'); 

outdir_figures = strcat(outdir, '/figures/')
mkdir(outdir_figures)
print([outdir_figures 'histograms' '.pdf'], '-dpdf');


    



