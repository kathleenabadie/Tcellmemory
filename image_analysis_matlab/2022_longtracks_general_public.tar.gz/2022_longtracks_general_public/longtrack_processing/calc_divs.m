function calc_divs(dirname, outdir, filenames)

for h = 1:length(filenames)
    if ~contains(filenames(h).name, 'trlong') % make sure only looping through trlong files
        continue
    end
    clear('file')
    full_filename = strcat(dirname,filenames(h).name);
    file = load(full_filename);    
    
end