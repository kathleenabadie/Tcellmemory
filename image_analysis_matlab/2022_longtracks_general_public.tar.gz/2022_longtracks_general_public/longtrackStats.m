% function longtrackStats(in_folder)

% Plan
% 1. Get longtracks from all longtrack.mat files and put them in one place
% 2. Chop each longtrack into time windows and do linear fit; might need to
% try multple different time windows
% 3. Plot a histogram of slopes; ideally, we will see a peak for silent and
% a peak for active
% 4. Use histogram to generate the slope cutoffs for classifying a given
% slope as OFF or ON. We will need this classification later
% 5. Now we need to locate the activation and silencing events. Go through
% each time window in each longtrack and compare 2 fits: (1) a single
% linear fit, (2) a piecewise linear fit
% 5a. Use an F test (or chi-squared? find the appropriate statistical fit)
% to determine whether the points in each time window are better fit by a
% linear or a two-piece linear. 
% 5b. Save the best fit
% 6. If the best fit is a single line, determine whether it represents ON
% or OFF (use slope cutoffs identified in 4.)
% 6a. If the best fit is two lines, determine separately for each whether
% the line represents ON or OFF (use slope cutoffs identified in 4.)
% 7. Go through all fitted lines, now labeled as ON or OFF, and identify
% transitions (OFF to ON; ON to OFF)
% 7a. Save activation time points and silencing time points
% 8. Once I have all of this information, I can also extract other metrics
% of interested such as activation duration (t_silencing - t_activation)

% Questions



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear

t_inc = 20; % length of time window in hours

cd '../longtracks/tracks_test/'

% load all .mat files in folder
all_longtracks = [];
mat_files = dir('*.mat'); % get list of all .mat files in the folder
for i = 1:length(mat_files) 
    file_name = mat_files(i).name 
    mat = load(file_name);
    % go through each longtrack and chop it into time pieces 

    for j = 1:length(mat.trlong) % loop through each longtrack
%         all_t_windows = [];
%         all_tbet_windows = [];
%         all_tcf1_windows = [];
        t_cutoff = t_inc; % initial cutoff time is 20 hrs
        m = 1;
        k = 1;
        while t_cutoff <= mat.trlong(j).t(length(mat.trlong(j).t)) %% need to change this to not waste so much data
            t_window = [];
            tbet_window = [];
            tcf1_window = [];
%             disp(length(mat.trlong(j).t))
%             disp(mat.trlong(j).t(k))
            while k <= length(mat.trlong(j).t) && mat.trlong(j).t(k) < t_cutoff
                t_window = [t_window mat.trlong(j).t(k)];
                tbet_window = [tbet_window mat.trlong(j).tbet(k)];
                tcf1_window = [tcf1_window mat.trlong(j).tcf1(k)];
                k = k+1;     
                % I could do my fitting here if I want
            end
%         all_t_windows = [all_t_windows t_window];
%         all_tbet_windows = [all_tbet_windows tbet_window];
%         all_tcf1_windows = [all_tcf1_windows tcf1_window];
            if isempty(t_window)
            else   
                all_t_windows{m} = t_window;
                all_tbet_windows{m} = tbet_window;
                all_tcf1_windows{m} = tcf1_window;
          
            end
            m = m+1;
            t_cutoff = t_cutoff + t_inc;

        end
        

        mat.trlong(j).t_windows = all_t_windows;
        mat.trlong(j).tbet_windows = all_tbet_windows; 
        mat.trlong(j).tcf1_windows = all_tcf1_windows;
    
    end
    mat_files(i).trlong = mat.trlong;   % save all the long tracks to the mat file
    mat_write = matfile(file_name,'Writable', true);
    mat_write.trlong = mat_files(i).trlong;
end
        

% Okay, now I have newly saved mat files in which the trlong field contails
% the t, tcf1, and tbet broken up into chunks.
% Now, I need to do (1) a single linear and (2) a two-piece linear fit to
% each time segment. Then conpare which fit is better.
% Once I have the best fit of the two for each segment, I will plot a
% histogram of slopes
            
            
            
        
        

            
    
    