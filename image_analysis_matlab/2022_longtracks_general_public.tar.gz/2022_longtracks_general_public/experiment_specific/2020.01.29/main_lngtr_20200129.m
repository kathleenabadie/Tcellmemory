
clear all

%%  USER INPUT
indir = '/data/abadiek/Imaging/Data_and_Processsing/20200129_CD8_KL_infl/20200129_CD8_KL_infl_raw_ANALYZED_20200225_01-41-21/';

% Use this one for full pipeline analysis 
outdir_base = [indir 'longtracks_' datestr(datetime('now'),'yyyymmdd_HH-MM-SS')];

% lin file basename
lin_name = 'lin_0319';

% conditions and corresponding position start folders 
cond = ["0_IL12", "1_IL12"];
cond_pos_starts = [1, 71, 158];


%%
% Go through all position folders in indir and store positions and lin
% files to analyze

for c = 1:length(cond)
    
    outdir = strcat(outdir_base, '_', convertStringsToChars(cond(c)), '/');
    cond_pos_vec = cond_pos_starts(c):1:cond_pos_starts(c+1);
    lin_files = [];
    positions = [];
    allcontents = dir(indir);
    dirFlags = [allcontents.isdir];
    allfolders = allcontents(dirFlags);
    for f = 1:length(allfolders)
        % find positions folders
        if contains(allfolders(f).name, 'pos')
            if ~ismember(str2num(allfolders(f).name(5:end)), cond_pos_vec)               
                continue
            end
            pos_files = dir([allfolders(f).folder '/' allfolders(f).name]);
            pos_lin_files = [];
            pos_lin_dn = [];
            % go through all files in pos folder
            for g = 1:length(pos_files)
                if contains(pos_files(g).name, lin_name)
                    pos_lin_files = [pos_lin_files pos_files(g)];
                    pos_lin_dn = [pos_lin_dn pos_files(g).datenum];
                end
            end
            if ~isempty(pos_lin_files)
                [max_dn, loc] = max(pos_lin_dn); % get most recent lin file with correct basename
                lin_files = [lin_files string(pos_lin_files(loc).name)]  % add to list of lin_file             
                positions = [positions, string(allfolders(f).name)]; % also add position to list of positions 
            end
        end
    end




    %% Run pipeline on positions and lin files identified in above code block

    % generate parameter file for image procesing.
    mkdir(outdir)

    disp(length(positions))
    for i = 1:length(positions)
        position = positions(i)
        position = convertStringsToChars(position)
        folder = strcat(indir, position)
        file = lin_files(i)
        file = convertStringsToChars(file)
        makeLongTracks_KA_20200129(folder,file,outdir, position);
    end
end
