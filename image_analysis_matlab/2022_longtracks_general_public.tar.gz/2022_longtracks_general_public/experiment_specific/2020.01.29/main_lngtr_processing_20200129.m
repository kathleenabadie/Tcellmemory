clear all;
close all;

%%  USER INPUT
indir_base = '/data/abadiek/Imaging/Data_and_Processsing/20200129_CD8_KL_infl/20200129_CD8_KL_infl_raw_ANALYZED_20200225_01-41-21/';
longtracks_folder = 'longtracks_20211025_11-53-34';

% conditions 
cond = ["0_IL12", "1_IL12"];

%%
for c = 1:length(cond)  
    dirname = strcat(indir_base, longtracks_folder, '_', convertStringsToChars(cond(c)), '/', 'tracks/');
    outdir = strcat(indir_base, longtracks_folder, '_', convertStringsToChars(cond(c))); 
    filenames = dir(dirname);
    
    % calculate derivatives and save to lin file
    calc_derivative_all(dirname, outdir, filenames);
    
    % Resave trlong.mat file to contain only one the trlong field for
    % each lin - to facilitate trlong export to R
    dirname = strcat(indir_base, longtracks_folder, '_', convertStringsToChars(cond(c)), '/', 'tracks/');
    outdir = strcat(indir_base, longtracks_folder, '_', convertStringsToChars(cond(c)), '/', 'tracks_sep_trlong_trs/'); 
    filenames = dir(dirname);
    save_trlong(dirname, outdir, filenames)
    save_trs(dirname, outdir, filenames)  
end
