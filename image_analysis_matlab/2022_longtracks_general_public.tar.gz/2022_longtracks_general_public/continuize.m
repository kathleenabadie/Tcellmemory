function yout = continuize(t,t1,y,y1,avglen);
   % Y = CONTINUIZE(T,T1,Y,Y1,AVGLEN);
   
   N = avglen;  % this is the length of the truncated trace for fitting
  
   if length(y)>N    % get first trace
       ys = y(end-N:end);
       ts = t(end-N:end);
   else
       ys = y;   % take entire trajectory
       ts = t;
   end
   
   if length(y1)>N   % get second trace
       y1s = y1(1:N);
       t1s = t1(1:N);
   else
       y1s = y1;
       t1s = t1;
   end
   
   % try this, first fit last few data points,
   
   tmid = (ts(end) + t1s(1))/2;   % find mid-point of two trajectories
   
   if (length(ts)>2)   % can fit to straight line
       f0 = fit(ts', ys','poly1','Robust','bisquare');      
   else    % data points are too short
       f0.p1 = 0;
       f0.p2 = mean(ys(:));
   end
      
   if (length(t1s)>2)   % can fit to straight line
       f1 = fit(t1s',y1s','poly1','Robust','bisquare');
   else    % data points are too short
       f1.p1 = 0;
       f1.p2 = mean(y1s(:));
   end
   
   offset = (f0.p1*tmid + f0.p2) - (f1.p1*tmid + f1.p2);  % find the point where linear fits intersect at the mid-point
   yout = [y y1+offset];

   % check the figure fit 
   %figure;
   %plot([t t1], [y y1+om],'rx'); hold on;
   %plot([ts t1s], fr([ts t1s],'k'));
   %keyboard
   
end