% lontracksSlopes

% 1. Smooth curve for each longtrack
% 2. Take derivative 
% 3. Histogram of slopes (over what time period?)

cd '../longtracks/tracks_test/'

tcf1_max = 250000;
tbet_max = 250000;
tmax = 100;   % maximum amount of time, for plotting

% load all .mat files in folder

all_tbet_slopes = [];
all_tcf1_slopes = [];
all_av_tbet_slopes = [];
all_av_tcf1_slopes = [];
mat_files = dir('*.mat'); % get list of all .mat files in the folder
for i = 1:length(mat_files) 
    file_name = mat_files(i).name 
    mat = load(file_name);
    
 
    for j = 1:length(mat.trlong) % loop through each longtrack
        longtrack = mat.trlong(j);
        t = longtrack.t;
        tbet = longtrack.tbet
        tcf1 = longtrack.tcf1
        
        figure(1)
        plot(t,tbet,"*")
%         title(['Tbet ' file_name ', tracks: ' num2str(tr)])
        hold on
        figure(2)
        plot(t,tcf1,"*")
%         title(['Tcf1 ' file_name ', tracks: ' num2str(tr)])
        hold on

        % try smoothing
        tbet_sm = transpose(smooth(tbet));
        tcf1_sm = transpose(smooth(tcf1));
        
        figure(1)
        plot(t, tbet_sm, "-")
        hold on
        figure(2)
        plot(t,tcf1_sm,"-")
        hold on

        % now take derivative of smoothed data
        h = 0.5; % step size
        tbet_der = diff(tbet_sm)/h;
        tcf1_der = diff(tcf1_sm)/h;
        
        
        disp(length(tbet_sm))
        disp(length(tbet_der))


        figure(1)
%         plot(t(1:length(tbet_der)),tbet_der)
        plot(t(1:length(tbet_der)),tbet_der)
        hold on
        figure(2)
%         plot(t(1:length(tcf1_der)),tcf1_der)
        plot(t(1:length(tbet_der)),tbet_der)
        hold on 

        % store
        mat.trlong(j).tbet_der = tbet_der;
        mat.trlong(j).tcf1_der = tcf1_der;
        
        % average slopes a bit before analyzing for histogram
        av_step = 4;
        tbet_der_av = [];
        tcf1_der_av = [];
        t_av = [];
        for k = 1:(length(tbet_der)-av_step)
            av = mean(tbet_der(k:k+av_step));
            tbet_der_av = [tbet_der_av av];
            av = mean(tcf1_der(k:k+av_step));
            tcf1_der_av = [tcf1_der_av av];
            av = mean(t(k:k+av_step));
            t_av = [t_av av];
        end
        
        % store
        mat.trlong(j).tbet_der_av = tbet_der_av;
        mat.trlong(j).tcf1_der_av = tcf1_der_av;
        mat.trlong(j).t_av = t_av;
        
        figure(1)
        plot(t_av, tbet_der_av,"x")
        hold off
        figure(2)
        plot(t_av, tcf1_der_av,"x")
        hold off
        
        
        all_tbet_slopes = [all_tbet_slopes tbet_der];
        all_tcf1_slopes = [all_tcf1_slopes tcf1_der];
        
        all_av_tbet_slopes = [all_av_tbet_slopes tbet_der_av];
        all_av_tcf1_slopes = [all_av_tcf1_slopes tcf1_der_av];
        
        
  
    end
    % save files
    mat_files(i).trlong = mat.trlong;   % save all the long tracks to the mat file
    mat_write = matfile(file_name,'Writable', true);
    mat_write.trlong = mat_files(i).trlong;
    

end



% Plot histograms of all slopes
figure(5)
histogram(all_tbet_slopes)
figure(6)
histogram(all_tcf1_slopes)

figure(7)
histogram(all_av_tbet_slopes)
title('Tbet slopes')
figure(8)
histogram(all_av_tcf1_slopes)
title('Tcf1 slopes')

keyboard

% Use histograms to identify slopes that constitute OFF and ON promotors
% use averaged histograms

% Not sure how to do this, so for now I will just visually identify the
% threshold slopes for activation
% From histograms:
% tbet 1.9e4
% tcf 2.5e3
% or 1.25 e4

tbet_thresh = 1e3;
tcf1_thresh = 2.5e3;

% Not, go through each track and find activation time, silencing time, and
% activation duration
% How to do this.. Need to throw out little blips (activation time < 0.5
% hr? or one time step?)

% Loop through all longtracks within each mat file. Go through every time
% point in t_av and assess corresponding slope value. Keep track of if
% given promoter is active or not. If slope > threshold, (for 
% at least three time points?) it is active 

mat_files = dir('*.mat'); % get list of all .mat files in the folder
for i = 1:length(mat_files) 
    file_name = mat_files(i).name;
    mat = load(file_name);
    
 
    for j = 1:length(mat.trlong) % loop through each longtrack
        longtrack = mat.trlong(j);
        t_av = longtrack.t_av;
        tbet_der_av = longtrack.tbet_der_av;
        tcf1_der_av = longtrack.tcf1_der_av;
        
        tbet_state = 0; % 0 denotes off; 1 denotes on
        tcf1_state = 0;
        tbet_oncount = 0;
        tcf1_oncount = 0;
        tbet_offcount = 0;
        tcf1_offcount = 0;
        tbet_act_t = [];
        tcf1_act_t = [];
        tbet_sil_t = [];
        tcf1_sil_t = [];
        min_dur = 6;
        for k = 1:length(t_av)
            % first for tbet
            if tbet_der_av(k) >= tbet_thresh
                tbet_oncount = tbet_oncount+1;
                tbet_offcount = 0;
                if (tbet_oncount >= min_dur) && tbet_state == 0
                    tbet_state = 1;
                    tbet_act_t = [tbet_act_t t_av(k-(min_dur-1))];
                end
            else
                tbet_oncount = 0;
                tbet_offcount = tbet_offcount+1;
                if (tbet_offcount >= min_dur) && tbet_state == 1
                    tbet_state = 0;
                    tbet_sil_t = [tbet_sil_t t_av(k-(min_dur-1))];
                end
            end
            % for tcf1
            if tcf1_der_av(k) >= tcf1_thresh
                tcf1_oncount = tcf1_oncount+1;
                tcf1_offcount = 0;
                if (tcf1_oncount) >= min_dur && tcf1_state == 0
                    tcf1_state = 1;
                    tcf1_act_t = [tcf1_act_t t_av(k-(min_dur-1))];
                end
            else
                tcf1_oncount = 0;
                tcf1_offcount = tcf1_offcount+1;
                if (tcf1_offcount >= (min_dur-1)) && tcf1_state == 1
                    tcf1_state = 0;
                    tcf1_sil_t = [tcf1_sil_t t_av(k-(min_dur-1))];
                end
            end
        end
                    
        % store
        mat.trlong(j).tbet_act_t = tbet_act_t;
        mat.trlong(j).tbet_sil_t = tbet_sil_t;
        mat.trlong(j).tcf1_act_t = tcf1_act_t;
        mat.trlong(j).tcf1_sil_t = tcf1_sil_t; 
    end
    mat_files(i).trlong = mat.trlong;   % save all the long tracks to the mat file
    mat_write = matfile(file_name,'Writable', true);
    mat_write.trlong = mat_files(i).trlong;
     
   
end    
        

% Final plotting

for i = 1:length(mat_files) 
    file_name = mat_files(i).name 
    mat = load(file_name);
    
    for j = 1:length(mat.trlong)
        longtrack = mat.trlong(j);
        divtime = longtrack.divtime;
        tbet = longtrack.tbet;
        tcf1 = longtrack.tcf1;
        t = longtrack.t;
        tbet_act_t = longtrack.tbet_act_t;
        tbet_sil_t = longtrack.tbet_sil_t;
        tcf1_act_t = longtrack.tcf1_act_t;
        tcf1_sil_t = longtrack.tcf1_sil_t;
        tr = longtrack.tr;
        tbet_der = longtrack.tbet_der;
        tcf1_der = longtrack.tcf1_der;
        tbet_der_av = longtrack.tbet_der_av;
        tcf1_der_av = longtrack.tcf1_der_av;
        t_av = longtrack.t_av;

        
        figure(9)
        
        subplot(2,1,1); plot(t, tbet,['bx-']);  title([file_name ', tracks: ' num2str(tr)]);
        ylabel('tbet integrated intensity');
        xlabel('time (hours)');
        axis([0 tmax 0 tbet_max]); hold on;
        for d = 1:length(divtime)
            plot([divtime(d) divtime(d)], [0 tbet_max],'k:'); 
        end
        for d = 1:length(tbet_act_t)
            plot([tbet_act_t(d) tbet_act_t(d)], [0 tbet_max],'g'); 
        end
        for d = 1:length(tbet_sil_t)
            plot([tbet_sil_t(d) tbet_sil_t(d)], [0 tbet_max],'r'); 
        end
        hold off
        axis square

       % tcf1 plot with division lines and track listing 
        subplot(2,1,2); plot(t, tcf1,['rx-']); 
        ylabel('tcf1 integrated intensity');
        xlabel('time (hours)');
        axis([0 tmax 0 tcf1_max]); hold on;        
        for d = 1:length(divtime)
            plot([divtime(d) divtime(d)], [0 tcf1_max],'k:');
        end
        for d = 1:length(tcf1_act_t)
            plot([tcf1_act_t(d) tcf1_act_t(d)], [0 tcf1_max],'g'); 
        end
        for d = 1:length(tcf1_sil_t)
            plot([tcf1_sil_t(d) tcf1_sil_t(d)], [0 tcf1_max],'r'); 
        end
        hold off
        axis square
        print(['figures_activity/' file_name '_' num2str(i) '_' num2str(j) '.pdf'], '-dpdf');
        close all;
        
        
        figure(10)
        
        subplot(2,1,1); plot(t_av, tbet_der_av,['bx-']);  title([file_name ', tracks: ' num2str(tr)]);
        ylabel('tbet DERIVATIVE');
        xlabel('time (hours)');
        axis([0 tmax 0 0.5e5]); hold on;
        for d = 1:length(divtime)
            plot([divtime(d) divtime(d)], [0 tbet_max],'k:'); 
        end
        for d = 1:length(tbet_act_t)
            plot([tbet_act_t(d) tbet_act_t(d)], [0 tbet_max],'g'); 
        end
        for d = 1:length(tbet_sil_t)
            plot([tbet_sil_t(d) tbet_sil_t(d)], [0 tbet_max],'r'); 
        end
        hold off
        axis square

       % tcf1 DERIVATIVE plot with division lines and track listing 
        subplot(2,1,2); plot(t_av, tcf1_der_av,['rx-']); 
        ylabel('tcf1 DERIVATIVE');
        xlabel('time (hours)');
        axis([0 tmax 0 0.5e5]); hold on;        
        for d = 1:length(divtime)
            plot([divtime(d) divtime(d)], [0 tcf1_max],'k:');
        end
        for d = 1:length(tcf1_act_t)
            plot([tcf1_act_t(d) tcf1_act_t(d)], [0 tcf1_max],'g'); 
        end
        for d = 1:length(tcf1_sil_t)
            plot([tcf1_sil_t(d) tcf1_sil_t(d)], [0 tcf1_max],'r'); 
        end
        hold off
        axis square
        print(['figures_derivatives/' file_name '_' num2str(i) '_' num2str(j) '.pdf'], '-dpdf');
        close all;
        
    end
end


% Now I want to extract 

        
        
      