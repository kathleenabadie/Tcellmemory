
clear all
close all

cd '../longtracks/tracks_test/'

mat = load('pos 112_trlong.mat')
cd ..

x = mat.trlong(2).t_windows{1};
y2 = mat.trlong(2).tbet_windows{1};
% 
% % linear fit
% [p,S] = polyfit(x,y2,1)
% 
% % piecewise fit
% 
% 
% prescription = slmset('order',2); % piecewise linear
% slm = slmengine(x,y2,prescription); % create model
% fitLine = slmeval(x,slm); % evaluate model
% figure;plot(x,y2);
% hold on;plot(fitLine);



% 
% plot(x,y2,'*')
% hold on
% b=nlinfit(x,y2,@piecewise, [1 1 1 1])
% 
% xh=linspace(x(1),x(end));
% yh=piecewise(b,xh);
% plot(xh,yh)







% % % Random data...
% xdata = linspace(-2,3,101);
% ydata = log(abs(10./(10+1i*10.^xdata))) + 0.5*randn(size(xdata));
% xdata = x
% ydata = y2
% % print("lb")
% disp([min(ydata) -inf -inf])
% % print("up")
% disp([max(xdata) inf 0])
% 
% plot(xdata,ydata,'*')
% F = @(B,xdata) min(B(1),B(2)+B(3)*xdata)   %Form of the equation
% IC = [min(ydata) min(ydata) 0]; %Initial guess
% B = lsqcurvefit( F,IC,xdata,ydata,[min(ydata) -inf -inf],[max(xdata) inf 0]);
% hold all;
% plot(xdata,F(B,xdata));
% a = (B(1) - B(2)) / B(3)
% cte = B(1)
% c = B(2)
% d = B(3)


xdata = x
ydata = y2
plot(xdata, ydata, "*")

% fun = @(theta, xdata) theta(1) + ...
%                          (xdata<=theta(2)) .* theta(3) .* xdata + ...
%                          (xdata>theta(2)) .* (theta(3) * theta(2) + ...
%                                               theta(4) .* (xdata-theta(2)))
%                                           
% theta = lsqcurvefit(fun, [0; 0; 0; 0], xdata, ydata)
% 
% yfit = fun(theta, x)
% 
% plot(xdata,ydata,'*')
% plot(xdata,yfit)