function trall = lin_dfs(trs, varargin)

    if (nargin == 1)  % initialize the trackall structure
        trnow = 1;
        trall = struct([]);
    else
        trnow = varargin{1};
        trall = varargin{2}; 
    end
    
    j = trnow(end);     % this is the current track  
    children = trs(j).children;   % find children of this track
    
    if isempty(children);  % this is the terminal node (leaf) of the track
        trall
        trall(end+1).tr = trnow;   % add current track list
    elseif (length(children)==1)  % exactly one child
        trnow = [trnow children(1)];   % append last child to the end of the current track
        trall = lin_dfs(trs, trnow, trall);  
    elseif (length(children)==2)  % two children
        trnow = [trnow children(1)];   % generate trajectory for first child
        trall = lin_dfs(trs, trnow, trall);
        
        trnow(end) = [];   % delete the first child, now enter the second child
        trnow = [trnow children(2)];   % generate trajectory for second child
        trall = lin_dfs(trs, trnow, trall);
    end
end
        
        
        
        
